import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:url_launcher/url_launcher.dart';

// ─────────────────────────────────────────────────────────────
//  CONFIG — change these two lines only
// ─────────────────────────────────────────────────────────────
const String kSiteBase = 'https://townpostr.com';
const String kStartUrl = 'https://townpostr.com/ledger/'; // PWA start_url
const Color kThemeColor = Color(0xFF1976D2);              // manifest theme_color

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: kThemeColor,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const TownpostrApp());
}

class TownpostrApp extends StatelessWidget {
  const TownpostrApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Townpostr',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: kThemeColor, useMaterial3: true),
      home: const WebShell(),
    );
  }
}

class WebShell extends StatefulWidget {
  const WebShell({super.key});
  @override
  State<WebShell> createState() => _WebShellState();
}

class _WebShellState extends State<WebShell> {
  InAppWebViewController? _controller;
  PullToRefreshController? _pullToRefresh;
  double _progress = 0;
  bool _offline = false;

  @override
  void initState() {
    super.initState();
    _requestStartupPermissions();
    _pullToRefresh = PullToRefreshController(
      settings: PullToRefreshSettings(color: kThemeColor),
      onRefresh: () async => _controller?.reload(),
    );
  }

  // Ask once at launch so the directory's location + photo upload work smoothly.
  Future<void> _requestStartupPermissions() async {
    await [
      Permission.locationWhenInUse,
      Permission.camera,
      Permission.photos,
      Permission.storage,
    ].request();
  }

  // tel:, mailto:, whatsapp:, maps links etc. open in their own apps.
  bool _isExternal(String url) {
    final u = url.toLowerCase();
    if (u.startsWith('http://') || u.startsWith('https://')) {
      // keep townpostr.com in-app; send other web hosts (e.g. google maps) out
      return !u.contains('townpostr.com');
    }
    return true; // any non-http scheme is external
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (_controller != null && await _controller!.canGoBack()) {
          _controller!.goBack();
        } else {
          // at the first page → confirm exit
          final exit = await showDialog<bool>(
            context: context,
            builder: (c) => AlertDialog(
              title: const Text('Exit Townpostr?'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
                TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yes')),
              ],
            ),
          );
          if (exit == true) SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: _offline ? _offlineView() : _webView(),
        ),
      ),
    );
  }

  Widget _webView() {
    return Stack(
      children: [
        InAppWebView(
          initialUrlRequest: URLRequest(url: WebUri(kStartUrl)),
          pullToRefreshController: _pullToRefresh,
          initialSettings: InAppWebViewSettings(
            javaScriptEnabled: true,
            useOnDownloadStart: true,
            mediaPlaybackRequiresUserGesture: false,
            allowsInlineMediaPlayback: true,
            geolocationEnabled: true,           // GPS for the directory
            useHybridComposition: true,
            supportZoom: false,
            transparentBackground: true,
            userAgent:
                'Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/126.0 Mobile Safari/537.36 TownpostrApp/1.0',
          ),
          onWebViewCreated: (c) => _controller = c,
          onProgressChanged: (c, p) {
            setState(() => _progress = p / 100);
            if (p == 100) _pullToRefresh?.endRefreshing();
          },
          onGeolocationPermissionsShowPrompt: (c, origin) async {
            return GeolocationPermissionShowPromptResponse(
              origin: origin, allow: true, retain: true);
          },
          onPermissionRequest: (c, req) async {
            return PermissionResponse(
              resources: req.resources,
              action: PermissionResponseAction.GRANT,
            );
          },
          shouldOverrideUrlLoading: (c, action) async {
            final url = action.request.url?.toString() ?? '';
            if (_isExternal(url)) {
              await _openExternal(url);
              return NavigationActionPolicy.CANCEL;
            }
            return NavigationActionPolicy.ALLOW;
          },
          onReceivedError: (c, req, err) {
            if (req.isForMainFrame == true) setState(() => _offline = true);
          },
        ),
        if (_progress < 1.0)
          LinearProgressIndicator(value: _progress, color: kThemeColor,
              backgroundColor: Colors.transparent),
      ],
    );
  }

  Widget _offlineView() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.wifi_off, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          const Text('No internet connection',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kThemeColor),
            onPressed: () async {
              final r = await Connectivity().checkConnectivity();
              if (!r.contains(ConnectivityResult.none)) {
                setState(() => _offline = false);
                _controller?.reload();
              }
            },
            child: const Text('Retry', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
