# Townpostr — build the APK on GitHub (no powerful PC needed)

GitHub builds the app on their servers and gives you the APK to download.
Your computer only uploads a few small files.

## What's in here
- `pubspec.yaml`, `lib/main.dart`  → the Flutter app
- `.github/workflows/build.yml`    → tells GitHub how to build the APK

## Steps (about 10–15 minutes, most of it waiting)

1. **Make a free GitHub account** at https://github.com (skip if you have one).

2. **Create a new repository**
   - Click the **+** (top-right) → **New repository**.
   - Repository name: `townpostr`
   - Choose **Private** (or Public, your call) → click **Create repository**.

3. **Upload these files**
   - On the new repo page, click the link **“uploading an existing file”**
     (or the **Add file → Upload files** button).
   - Unzip the folder I gave you, then **drag ALL of its contents** into the
     upload box — including the `.github` folder. (If your PC hides the
     `.github` folder, turn on “show hidden files”, or see the manual step below.)
   - Scroll down, click **Commit changes**.

4. **The build starts automatically.** Click the **Actions** tab at the top.
   You'll see a run called **“Build APK”** with a spinning yellow dot.
   Wait for it to turn into a **green ✓** (about 5–10 minutes the first time).

5. **Download the APK**
   - Click the finished green run.
   - Scroll to the **Artifacts** section at the bottom → click **townpostr-apk**.
   - It downloads a zip → unzip it → inside is **app-debug.apk**.

6. **Install on your phone**
   - Send `app-debug.apk` to your phone (Drive / WhatsApp-to-yourself / USB).
   - Settings → Apps → **Install unknown apps** → allow for the app you open it with.
   - Tap the APK → Install → open. Done.

## If the `.github` folder won't upload
Create the file manually instead:
   - In your repo click **Add file → Create new file**.
   - In the name box type exactly: `.github/workflows/build.yml`
     (typing the `/` creates the folders automatically).
   - Paste the contents of `build.yml` → **Commit changes**.
   - Then upload `pubspec.yaml` and the `lib` folder the same way.

## Re-building after a change
Any time you upload a new version of a file and commit, GitHub rebuilds the APK
automatically. Or go to **Actions → Build APK → Run workflow** to build on demand.
